// db.js — "banco de dados" simples em arquivo JSON.
// Sem dependências externas: usa só o módulo nativo "fs" do Node.
// Troque por SQLite/Postgres depois sem mudar a API (routes/*.js só chamam as funções daqui).

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DB_PATH = path.join(__dirname, 'data.json');

function hashSenha(senha, salt) {
  salt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(senha, salt, 64).toString('hex');
  return { salt, hash };
}

function conferirSenha(senha, salt, hash) {
  const tentativa = crypto.scryptSync(senha, salt, 64);
  const alvo = Buffer.from(hash, 'hex');
  return tentativa.length === alvo.length && crypto.timingSafeEqual(tentativa, alvo);
}

function seed() {
  const senhaPadrao = hashSenha('123456');
  return {
    usuarios: [
      { id: 1, nome: 'Marcos Andrade', email: 'admin@proconecta.com.br', papel: 'administrador', celular: '(12) 99999-0001', cliente_id: null, ...senhaPadrao },
      { id: 2, nome: 'Isaías Lobo', email: 'isaias@proconecta.com.br', papel: 'tecnico', celular: '(12) 99999-0002', cliente_id: null, ...senhaPadrao },
      { id: 3, nome: 'Renata Alves', email: 'renata@proconecta.com.br', papel: 'tecnico', celular: '(12) 99999-0003', cliente_id: null, ...senhaPadrao },
      { id: 4, nome: 'Cliente ABC', email: 'cliente@abc.com.br', papel: 'cliente', celular: '(12) 99999-0004', cliente_id: 1, ...senhaPadrao },
    ],
    clientes: [
      { id: 1, nome_empresa: 'Cliente ABC Ltda', contato: 'Marcos (manutenção)', telefone: '(12) 3921-0000', nivel_acesso: 'completo' },
    ],
    equipamentos: [
      { id: 1, cliente_id: 1, tipo: 'Máquina de Gelo', modelo: 'Promarking MP5-80P', numero_serie: '2301013587', localizacao: 'Cozinha' },
      { id: 2, cliente_id: 1, tipo: 'Torre de Bebidas', modelo: 'TB-200', numero_serie: 'TB200-887', localizacao: 'Salão' },
    ],
    agenda: [
      {
        id: 1, tecnico_id: 2, cliente_id: 1, equipamento_id: 1,
        data_hora_inicio: '2026-09-12T08:00:00', data_hora_fim: '2026-09-12T11:00:00',
        tipo: 'corretiva', categoria: 'inloco', problema: 'Perda de referência do eixo Y',
        status: 'pendente', valor_servico: null, retrabalho: false,
      },
    ],
    visitas: [],
    biblioteca: [],
    _seq: { usuarios: 5, clientes: 2, equipamentos: 3, agenda: 2, visitas: 1, biblioteca: 1 },
  };
}

function load() {
  if (!fs.existsSync(DB_PATH)) {
    const data = seed();
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
    return data;
  }
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}

function save(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function nextId(data, tabela) {
  const id = data._seq[tabela]++;
  return id;
}

module.exports = { load, save, nextId, hashSenha, conferirSenha, DB_PATH };
