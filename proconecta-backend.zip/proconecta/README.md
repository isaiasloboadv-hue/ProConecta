# Pro Conecta — Fase 1 (backend real)

Sistema real (não é mais protótipo clicável): login de verdade, banco de dados
que persiste em disco, e as regras de permissão por papel realmente aplicadas
no servidor.

## Como rodar

Só precisa ter o **Node.js** instalado (download em https://nodejs.org — versão
18 ou mais recente). Não precisa instalar nenhum pacote extra: o projeto não
usa `npm install`.

```
cd proconecta
node server.js
```

Abra **http://localhost:3000** no navegador.

Contas de teste (senha para todas: `123456`):

| Papel | E-mail |
|---|---|
| Administrador | admin@proconecta.com.br |
| Técnico | isaias@proconecta.com.br |
| Cliente | cliente@abc.com.br |

## O que já funciona de verdade

- **Login** com senha (hash + salt, sem senha em texto puro) e sessão por token assinado
- **Permissões reais**: o servidor recusa (403) uma ação fora do papel do usuário — ex.: técnico não consegue criar atividade, cliente não consegue cadastrar equipamento
- **Agenda**: administrador cria atividade escolhendo técnico e equipamento; técnico só vê a própria agenda
- **Diário técnico**: técnico registra causa/correção/resultado de uma atividade; ela fica "pendente" até o administrador aprovar
- **Aprovações**: administrador aprova ou reprova; ao aprovar, o caso entra automaticamente na Biblioteca
- **Biblioteca de Defeitos e Soluções**: pesquisável por equipamento/sintoma/causa/solução
- **Equipamentos**: cadastro e histórico (agenda + visitas) por equipamento
- **Usuários**: administrador cadastra novos técnicos/perfis

Tudo isso é validado no servidor, não só na tela — se você abrir o DevTools do
navegador e tentar chamar a API diretamente sem permissão, o servidor recusa
do mesmo jeito.

## Onde ficam os dados

Tudo fica em `data.json`, criado automaticamente na primeira vez que você roda
o servidor (com os dados de teste acima). Para começar do zero, apague esse
arquivo e rode `node server.js` de novo.

## Estrutura do projeto

```
proconecta/
├── server.js       servidor HTTP e todas as rotas da API
├── db.js           acesso ao "banco de dados" (arquivo data.json)
├── auth.js         hash de senha e token de sessão
├── data.json        os dados salvos (gerado automaticamente)
└── public/          o que o navegador carrega
    ├── index.html
    ├── style.css
    └── app.js        toda a lógica de tela, chamando a API real
```

## Por que sem framework (Express) e sem SQLite?

Rodei este protótipo em um ambiente sem acesso à internet, então não consegui
baixar pacotes do npm (`express`, `sqlite3`, `jsonwebtoken` etc.). Por isso
escrevi tudo só com os módulos que já vêm dentro do Node.js — funciona igual,
só que sem instalação nenhuma. É só trocar de lugar quando quiser evoluir:

- Trocar `data.json` por Postgres/SQLite de verdade: só mexe em `db.js`,
  o resto do código não muda.
- Trocar o roteamento manual por Express: só mexe em `server.js`.

## Colocar no ar de graça (sem precisar deixar seu computador ligado)

A opção mais simples sem cartão de crédito é o **Render** (render.com):

1. Crie uma conta grátis no **GitHub** (github.com) se ainda não tiver
2. Crie um repositório novo e suba esta pasta `proconecta` nele (pelo site
   mesmo dá pra arrastar os arquivos, não precisa saber usar Git por linha de
   comando)
3. Crie uma conta grátis no **Render** (render.com) — não pede cartão
4. No painel do Render: **New +** → **Web Service** → conecte esse repositório
5. Configuração: **Runtime = Node**, **Build Command** deixe em branco,
   **Start Command** = `node server.js`
6. Clique em **Deploy** — em alguns minutos você recebe um link tipo
   `https://proconecta.onrender.com` que funciona de qualquer lugar

**Importante sobre o plano grátis do Render:** ele não tem "disco
persistente" — ou seja, o arquivo `data.json` (onde ficam salvos os
usuários, agenda, etc.) pode ser resetado sempre que você atualizar o
código. Ótimo pra testar e mostrar pra outras pessoas; quando for para uso
real do dia a dia, aí sim vale migrar para um banco de dados de verdade
(Postgres, que o próprio Render oferece com um plano pago barato) — troca só
em `db.js`, o resto do sistema não muda. O plano grátis também "dorme" depois
de 15 minutos sem uso e demora uns 30-60 segundos pra acordar no primeiro
acesso seguinte — depois disso funciona normal.

Alternativas parecidas, também sem cartão: **Railway** (railway.app) e
**Fly.io** (fly.io) — o processo de deploy é bem parecido.

## Próximos passos (Fase 2 do documento de especificação)

- Perfis Supervisor e Financeiro
- Cotas de técnico por mês
- Prestação de contas com upload de nota fiscal
- Notificações (sino no app + e-mail/WhatsApp)
- Biblioteca de Procedimentos Preventivos e Documentação Técnica
- Chamados abertos pelo cliente com fluxo de orçamento
